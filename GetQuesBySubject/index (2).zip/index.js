const AWS = require('aws-sdk');
const mongoose = require('mongoose');
const ObjectId = require('mongoose').Types.ObjectId;
const path = require('path')

exports.handler = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const subjectId = event.subject_id;
    const courseId = event.course_id;

    try {
        await mongoose.connect('mongodb://upmyranks:upmyranks@docdb-2023-04-09-13-10-41.cgaao9qpsg6i.ap-south-1.docdb.amazonaws.com:27017/upmyranks', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            tls: true,
            tlsCAFile: path.join(__dirname, 'rds-combined-ca-bundle.pem')
        });

        const courses = await mongoose.connection.collection('courses');
        const courseData = await courses.find({ _id: new ObjectId(courseId) }).toArray();
        console.log("Cdata", courseData);

        const subjects = await mongoose.connection.collection('subjects');
        const subjectData = await subjects.find({ _id: new ObjectId(subjectId) }).toArray();
        console.log("sData", subjectData);

        if (!courseData || !subjectData) {
            return callback("Invalid course or subject id", null);
        }

        const course = courseData[0].name;
        console.log("cName", course)
        const subject = subjectData[0].name;
        console.log("sName", subject)

        // Fetch questions for the subject
        const questionsCollection = `questions_${course.toLowerCase()}`;
        const query = {
            'subjectId': new ObjectId(subjectId),
            'disabled': false
        };

        const allQuestions = await mongoose.connection.collection(questionsCollection)
            .find(query)
            .toArray();

        console.log("Qdata", allQuestions)
        return callback(null, {
            status_code: 200,
            response: {
                message: 'Questions fetched successfully',
                questions: allQuestions,
            }
        });
    } catch (error) {
        console.error("Error:", error);
        return callback({
            status_code: 500,
            error: error || "Error fetching questions",
        }, null);
    } finally {
        // Close the MongoDB connection
        mongoose.connection.close();
    }
};
