const mongoose = require('mongoose');

const authorSchema = new mongoose.Schema({
  name: String,
});

const Author = mongoose.model('Author', authorSchema);

exports.handler = async (event) => {
  try {
    // Connect to MongoDB using Mongoose
    await mongoose.connect('mongodb://upmyranks:upmyranks@docdb-2023-04-09-13-10-41.cgaao9qpsg6i.ap-south-1.docdb.amazonaws.com:27017/upmyranks?ssl=true&retryWrites=false');
    console.log("Connection Successfull")

    const result = await Author.find({ deleted: false }).select('_id name');

    await mongoose.disconnect();

    return {
      statusCode: 200,
      data: result
    };
  } catch (error) {
    console.error('Error getting authors:', error);
    return {
      statusCode: 500,
      message: 'Error getting authors', error: error.message
    };
  }
};
